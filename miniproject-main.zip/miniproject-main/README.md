Django implementation of a cart; used for miniproject
